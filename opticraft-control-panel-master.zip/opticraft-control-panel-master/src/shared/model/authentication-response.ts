/// <reference path="tsd.d.ts" />

interface AuthenticationResponse {
	username: string;
}

export = AuthenticationResponse;
