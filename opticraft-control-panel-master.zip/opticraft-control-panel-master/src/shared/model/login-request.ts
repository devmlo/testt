/// <reference path="tsd.d.ts" />

interface LoginRequest {
	username: string;
	password: string;
}
export = LoginRequest;
